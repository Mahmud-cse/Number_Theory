#include<bits/stdc++.h>
using namespace std;
int phi(int n){
	int ret=n;
	for(int i=2;i*i<=n;i++){
		if(n%i==0){
			while(n%i==0){
				n/=i;
			}
			ret-=ret/i;
		}
	}
	if(n>2){
		ret-=ret/n;
	}
	return ret;
}
int main()
{
	int r=phi(12);
	cout<<r<<endl;
	return 0;
}
