#include<bits/stdc++.h>
using namespace std;
int main(){
	int n,i;
	char s[100];
	vector<string>v;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>s;
		v.push_back(s);
	}
	sort(v.begin(),v.end());
	for(int i=0;i<n;i++){
		cout<<v[i]<<" ";
	}
	return 0;
}
