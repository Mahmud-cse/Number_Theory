#include<bits/stdc++.h>
using namespace std;
int main()
{
	cout<<"Yes"<<endl;
	return 0;
}
