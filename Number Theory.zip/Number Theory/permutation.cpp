#include<bits/stdc++.h>
using namespace std;
void display(int arr[],int n){
	for(int i=0;i<n;i++){
		cout<<arr[i]<<" ";
	}
	cout<<endl;
}
void perm(int arr[],int n){
	sort(arr,arr+n);
	do{
		display(arr,n);
	}while(next_permutation(arr,arr+n));
}
int main(){
	int n;
	cin>>n;
 	int arr[n];
 	for(int i=0;i<n;i++){
 		cin>>arr[i];
	 }
	 int a=sizeof(arr)/sizeof(arr[0]);
	 perm(arr,a);
	 return 0;
}
