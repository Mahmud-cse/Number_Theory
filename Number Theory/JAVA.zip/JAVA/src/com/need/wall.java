package com.need;

public class wall {
    private String direction;

    public wall(String direction) {
        this.direction = direction;
    }

    public String getDirection() {
        return direction;
    }
}
