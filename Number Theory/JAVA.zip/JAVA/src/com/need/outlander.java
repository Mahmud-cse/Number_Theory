package com.need;

public class outlander extends car{
    private int road_Service;

    public outlander(int road_Service) {
        super("Outlander","4WD", 5,5,6, false);
        this.road_Service = road_Service;
    }

    public void accelerate(int rate){
        int new_Velocity=getCurrent_velocity()+rate;
        if(new_Velocity==0){
            stop();
            change_Gear(1);
        }else if(new_Velocity>0 && new_Velocity<10){
            change_Gear(1);
        }else if(new_Velocity>10 && new_Velocity<20){
            change_Gear(2);
        }else if(new_Velocity>20 && new_Velocity<30){
            change_Gear(3);
        }else{
            change_Gear(4);
        }

        if(new_Velocity>0){
            change_velocity(new_Velocity,getCurrent_direction());
        }
    }
}
