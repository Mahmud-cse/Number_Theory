package com.need;
import java.util.Scanner;
public class problem3 {
    public static void main(String[] args) {
     Scanner s=new Scanner(System.in);
        System.out.println("Enter number of the elements in the array:");
        int n=s.nextInt();
     int a[]=new int[n];
        System.out.println("Enter elements:");
        for(int i=0;i<n;i++){
            a[i]=s.nextInt();
        }
        int max=Integer.MIN_VALUE;
        for(int i=0;i<n;i++){
            if(max<a[i]){
                max=a[i];
            }
        }
        System.out.println("Maximum value is:"+max);
    }
}
