package com.need;

public class car extends vehicle {
    private int wheels;
    private int doors;
    private int gears;
    private boolean isManual;

    private int current_Gear;

    public car(String name, String size, int wheels, int doors, int gears, boolean isManual) {
        super(name, size);
        this.wheels = wheels;
        this.doors = doors;
        this.gears = gears;
        this.isManual = isManual;
        this.current_Gear = 1;
    }

    public void change_Gear(int current_Gear) {
        this.current_Gear = current_Gear;
        System.out.println("Car.setCurrent_Gear():changed to "+this.current_Gear+" gear.");
    }

    public void change_velocity(int speed,int direction){
        move(speed,direction);
        System.out.println("car.change_velocity():velocity "+speed+" direction."+direction);
    }
}
