package com.need;

public class vehicle {
    private String name;
    private String size;

    private int current_velocity;
    private int current_direction;

    public vehicle(String name, String size) {
        this.name = name;
        this.size = size;
        this.current_direction=0;
        this.current_velocity=0;
    }
    public void steer(int direction){
        this.current_direction+=direction;
        System.out.println("vehicle.steer():Steering at: "+current_direction+" degrees.");
    }

    public void move(int velocity,int direction){
        current_direction=direction;
        current_velocity=velocity;
        System.out.println(" vehicle.move():moving at: "+current_velocity+" in direction."+current_direction);
    }

    public String getName() {
        return name;
    }

    public String getSize() {
        return size;
    }

    public int getCurrent_velocity() {
        return current_velocity;
    }

    public int getCurrent_direction() {
        return current_direction;
    }

    public void stop(){
        this.current_velocity=0;
    }
}
