package com.need;
class wasa{
    private boolean engine;
    private int cylinders;
    private String name;
    private int wheels;

    public wasa(int cylinders, String name) {
        this.cylinders = cylinders;
        this.name = name;
        this.wheels=4;
        this.engine=true;
    }

    public String startEngine(){
        return "car-startEngine()";
    }

    public String accelerate(){
        return "car-accelerate()";
    }

    public String brake(){
        return "car-brake()";
    }

    public int getCylinders() {
        return cylinders;
    }

    public String getName() {
        return name;
    }
}

class carNews extends wasa{
    public carNews(int cylinders, String name) {
        super(cylinders, name);
    }

    @Override
    public String startEngine() {
        return getClass().getSimpleName()+" .startEngine()";
    }

    @Override
    public String accelerate() {
        return getClass().getSimpleName()+" .accelerate()";
    }

    @Override
    public String brake() {
        return getClass().getSimpleName()+" .brake()";
    }
}

public class main2 {
    public static void main(String[] args){
        wasa car=new wasa(8,"audi");
        System.out.println(car.accelerate())    ;
        System.out.println(car.brake());
        System.out.println(car.startEngine());

        carNews ok=new carNews(6,"BMW");
        System.out.println(ok.accelerate());
        System.out.println(ok.brake());
        System.out.println(ok.startEngine());

        Ford ford=new Ford(6,"Lmabo");
        System.out.println(ford.accelerate());
        System.out.println(ford.brake());
        System.out.println(ford.startEngine());
    }
}
