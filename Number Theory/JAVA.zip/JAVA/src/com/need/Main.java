package com.need;

import java.util.PrimitiveIterator;

public class Main {

    public static void main(String[] args) {
        ///INHERITANCE///
        /*outlander outlander=new outlander(31);
        outlander.accelerate(30);
        outlander.steer(30);*/

        ////COMPOSITION///
/*        wall wall1=new wall("north");
        wall wall2=new wall("south");
        wall wall3=new wall("east");
        wall wall4=new wall("west");

        Ceiling ceiling=new Ceiling(20,3);

        Bed bed=new Bed("Modern",4,3,2,1);

        Lamp lamp=new Lamp("Clasic",false,80);

        bedroom Bedroom=new bedroom("Redoy",wall1,wall2,wall3,wall4,ceiling,bed,lamp);
        Bedroom.makebed();
        Bedroom.getLamp().turnOn();*/

///ENCAPSULATION///

        /*Painter painter=new Painter(50,false);
        System.out.println("Initial pages count "+painter.getPagesPrinted());

        int pagesPrinted=painter.printPages(4);
        System.out.println("Pages printed was "+pagesPrinted+" new total print count for painter "+painter.getPagesPrinted());
        pagesPrinted=painter.printPages(2);
        System.out.println("Pages printed was "+pagesPrinted+" new total print count for painter "+painter.getPagesPrinted());*/

    }
}
