package com.need;

import  java.util.Scanner;

public class array {
    public static Scanner scanner=new Scanner(System.in);
    public static void main(String[] args){
       int[] myArray=getInterger(5);

       for(int i=0;i<myArray.length;i++){
           System.out.println("Element of "+i+" typed was "+myArray[i]);
       }
        System.out.println("The average is "+getAverage(myArray));

    }
    public static int[] getInterger(int number){
        System.out.println("Enter "+number+" integer.\r");
        int[] values=new int[number];

        for(int i=0;i<values.length;i++){
            values[i]=scanner.nextInt();
        }
        return  values;
    }

    public static double getAverage(int[] array){
        int sum=0;
        for(int i=0;i<array.length;i++){
            sum+=array[i];
        }
        return (double)sum/(double)array.length;
    }

}
