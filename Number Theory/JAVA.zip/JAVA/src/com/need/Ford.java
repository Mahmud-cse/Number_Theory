package com.need;

class Ford extends wasa{
    public Ford(int cylinders, String name) {
        super(cylinders, name);
    }

    @Override
    public String startEngine() {
        return "ford.startEngine()";
    }

    @Override
    public String accelerate() {
        return "ford.accelerate()";
    }

    @Override
    public String brake() {
        return "ford.brake()";
    }
}

