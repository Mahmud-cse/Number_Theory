package com.need;
import java.util.Scanner;
public class problem1 {
    public static void main(String[] args){
        Scanner s=new Scanner(System.in);
        System.out.println("Enter principal:");
        float p=s.nextFloat();
        System.out.println("Enter the rate of interest:");
        float r=s.nextFloat();
        System.out.println("Enter the time period:");
        float t=s.nextFloat();
        float si=(r*p*t)/100;
        System.out.println("The simple interest is:"+si);
    }
}
